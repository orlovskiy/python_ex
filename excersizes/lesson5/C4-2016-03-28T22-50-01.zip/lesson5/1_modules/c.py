print ('...loading %s...' % __name__)

def printing(text):
    print(text)