print ('...loading %s...' % __name__)
import c
foo = 1
bar = 2
def spam(text):
    print(text)